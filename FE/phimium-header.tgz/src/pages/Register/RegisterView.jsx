import { Link } from 'react-router-dom'

import registerBackground from '@/assets/images/background.jpg'
import { LanguageSwitcher } from '@/components/common'
import { useLanguage } from '@/context/languageContext.js'
import { ROUTES } from '@/routes/paths.js'

export function RegisterView({
  error,
  formData,
  handleChange,
  handleRegister,
  isLoading,
}) {
  const { t } = useLanguage()

  return (
    <div className="relative flex min-h-screen bg-white font-sans">
      <LanguageSwitcher className="absolute right-4 top-4 z-20" />

      <div className="relative hidden flex-col justify-between border-r border-gray-100 bg-blue-50 p-12 lg:flex lg:w-1/2">
        <div>
          <h1 className="text-2xl font-bold text-blue-600">Phimium</h1>
        </div>

        <div className="relative z-10 max-w-md">
          <h2 className="mb-6 text-5xl leading-tight font-bold text-slate-900">
            {t('auth.register.heroTitle')}
          </h2>
          <p className="mb-8 text-lg text-slate-600">
            {t('auth.register.heroText')}
          </p>

          <div className="space-y-4">
            <div className="flex w-max items-center rounded-xl bg-white p-4 shadow-sm">
              <span className="mr-3 text-blue-500">✓</span>
              <span className="font-medium text-slate-700">
                {t('auth.register.benefitSafety')}
              </span>
            </div>
            <div className="flex w-max items-center rounded-xl bg-white p-4 shadow-sm">
              <span className="mr-3 text-blue-500">✓</span>
              <span className="font-medium text-slate-700">
                {t('auth.register.benefitBuddy')}
              </span>
            </div>
          </div>
        </div>

        <div className="text-sm text-slate-500">
          © 2026 Phimium. {t('auth.tagline')}
        </div>

        <div
          className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-10"
          style={{ backgroundImage: `url(${registerBackground})` }}
        />
      </div>

      <div className="flex w-full flex-col justify-center px-8 sm:px-16 md:px-24 lg:w-1/2">
        <div className="mx-auto w-full max-w-md">
          <div className="mb-10">
            <h2 className="text-3xl font-bold text-slate-900">
              {t('auth.register.title')}
            </h2>
            <p className="mt-2 text-slate-500">
              {t('auth.register.subtitle')}
            </p>
          </div>

          <form className="space-y-5" onSubmit={handleRegister}>
            {error && (
              <div className="rounded-lg border border-red-100 bg-red-50 p-3 text-sm text-red-600">
                {error}
              </div>
            )}

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                {t('auth.register.fullName')}
              </label>
              <input
                type="text"
                name="fullname"
                value={formData.fullname}
                onChange={handleChange}
                placeholder={t('auth.register.fullNamePlaceholder')}
                className="w-full rounded-lg border border-slate-200 px-4 py-3 transition-all focus:border-transparent focus:ring-2 focus:ring-blue-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                Email
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="email@example.com"
                className="w-full rounded-lg border border-slate-200 px-4 py-3 transition-all focus:border-transparent focus:ring-2 focus:ring-blue-500 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                {t('auth.password')}
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                placeholder={t('auth.register.passwordHint')}
                className="w-full rounded-lg border border-slate-200 px-4 py-3 transition-all focus:border-transparent focus:ring-2 focus:ring-blue-500 focus:outline-none"
                required
              />
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  {t('auth.register.phone')}
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="0901234567"
                  className="w-full rounded-lg border border-slate-200 px-4 py-3 transition-all focus:border-transparent focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  {t('auth.register.birthdate')}
                </label>
                <input
                  type="date"
                  name="birthdate"
                  value={formData.birthdate}
                  onChange={handleChange}
                  className="w-full rounded-lg border border-slate-200 px-4 py-3 text-slate-600 transition-all focus:border-transparent focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="mt-4 flex w-full items-center justify-center rounded-lg bg-blue-600 py-3 font-medium text-white transition-colors hover:bg-blue-700 disabled:opacity-70"
            >
              {isLoading ? t('common.processing') : t('auth.register.submit')}
            </button>
          </form>

          <p className="mt-8 text-center text-sm text-slate-600">
            {t('auth.register.hasAccount')}{' '}
            <Link
              to={ROUTES.login}
              className="font-semibold text-blue-600 transition-colors hover:text-blue-700"
            >
              {t('auth.register.loginLink')}
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
